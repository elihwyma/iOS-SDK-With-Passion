// Copyright © 2020 Apple Inc. All rights reserved.

#ifdef __cplusplus
#define AP_EXTERN extern "C" __attribute__((visibility ("default")))
#else
#define AP_EXTERN extern __attribute__((visibility ("default")))
#endif
