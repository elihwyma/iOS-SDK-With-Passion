//
//  MLExport.h
//  CoreML_framework
//
//  Copyright © 2018 Apple Inc. All rights reserved.
//

#ifndef MLExport_h
#define MLExport_h

#define ML_EXPORT extern __attribute__((visibility ("default")))

#endif /* MLExport_h */
